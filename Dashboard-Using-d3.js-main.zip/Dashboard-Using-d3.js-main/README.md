# Dashboard-Using-d3.js
Dashboard using bootstrap , D3.js , javascript.<br> This dashboard has 4 tabs <br>    a) Overall Level,    In the overall level it has 3 graphs one has time graph which represent the overall store vs date .   <br> b) Store Level <br>  c) Product Level <br>   d) Region Level <br>   
